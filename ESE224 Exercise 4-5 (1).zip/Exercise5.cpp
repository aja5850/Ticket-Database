#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main()
{
	cout << "Expected Performance For Next Year Damage. " << endl;
	cout << "Enter Cause(Tree, MVA): ";
	string cause;
	cin >> cause;

	if (cause == "MVA")
	{
		for (int i = 0; i < MVAcauses.size(); i++)
		{
			expectedPerformanceData = MVAcauses[i].points.expectedPerformance;
			expectedPerformance.push_back(expectedPerformanceData);

			for (int i = 0; i < expectedPerformance.size(); i++)
			{
				for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
				{
					double MVA_average = expectedPerformance.size() / sizeof(expectedPerformance);
				}
			}
		}

		cout << "Expected Performance Damage: " << MVA_average;
	}

	else if (cause == "Insulator")
	{
		for (int i = 0; i < InsulatorCauses.size(); i++)
		{
			expectedPerformanceData = InsulatorCauses[i].points.expectedPerformance;
			expectedPerformance.push_back(expectedPerformanceData);

			for (int i = 0; i < expectedPerformance.size(); i++)
			{
				for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
				{
					double Insulator_average = expectedPerformance.size() / sizeof(expectedPerformance);
				}
			}
		}
	}

	cout << "\n";

	cout << "Time Without Power For Next Year" << endl;
	cout << "Please Enter a cause: ";
	string cause2;
	cin >> cause2;

	if (cause2 == "MVA")
	{
		for (int i = 0; i < MVAcauses.size(); i++)
		{
			timeWithoutPowerData = MVAcauses[i].avg_time.timeWithoutPower;
			timeWithoutPower.push_back(timeWithoutPowerData);

			for (int i = 0; i < timeWithoutPower.size(); i++)
			{
				for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
				{
					double MVA_average = timeWithoutPower.size() / sizeof(timeWithoutPower);
				}
			}
		}

		cout << "Expected Time Without Power: " << MVA_average;
	}

	else if (cause2 == "Insulator")
	{
		for (int i = 0; i < InsulatorCauses.size(); i++)
		{
			timeWithoutPowerData = InsulatorCauses[i].avg_time.timeWithoutPower;
			timeWithoutPower.push_back(timeWithoutPowerData);

			for (int i = 0; i < timeWithoutPower.size(); i++)
			{
				for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
				{
					double insulator_average = timeWithoutPower.size() / sizeof(timeWithoutPower);
				}
			}
		}

		cout << "Expected Time Without Power: " << insulator_average;
	}
}

