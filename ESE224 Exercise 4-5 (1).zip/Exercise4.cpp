#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

//Contains Information for Ticket
struct Ticket
{
    string line;
    string substation;
    string date;
    string time;
    string remark;
    string comment;
    string cause;
    int CustomerHours;
    int crew;
    int CAP;   
    int repairtime;
};

// Main Ticket Vector
vector<Ticket> tickets;

//Substation S
vector<Ticket> substationS;
vector<double> substationSrepairTime;

//Other 5 Substations 
vector<Ticket> AllOtherSubstations;
vector<double> AllOtherSubstationsRepairTime;

// Substation subvectors
vector<Ticket> EBtickets;
vector<Ticket> OFtickets;
vector<Ticket> RLtickets;
vector<Ticket> TMtickets;
vector<Ticket> HDtickets;

// Cause subvectors
vector<Ticket> TreeCause;
vector<Ticket> InsulatorCause;
vector<Ticket> MVACause;

// Add a new ticket for a new power outage at Substation S//
void addTicket(string line, string substation, string date, string time, string comment, string cause)
{
    // Create a new ticket and set its properties
    Ticket newTicket;
    newTicket.line = line;
    newTicket.substation = substation;
    newTicket.date = date;
    newTicket.time = time;
    newTicket.comment = comment;
    newTicket.cause = cause;

    // Add the new ticket to both tickets and substationS
    tickets.push_back(newTicket);

    if (substation == "S") 
    {
        substationS.push_back(newTicket);
    }
}

//Calculates the Average Repair Time for Similar Damages within SubstationS
void RepairTime(int repairtime)
{
    int RepairTime = 0;
    int SubstationS = 0;
    int AllSubstations = 0;

    for (int i = 0; i < substationS.size(); i++)
    {
        RepairTime = repairtime++;
        SubstationS++;
    }

    double averageRepairTime = RepairTime / SubstationS;

    substationSrepairTime.push_back(averageRepairTime);

    for (int i = 0; i < AllOtherSubstations.size(); i++)
    {
        RepairTime = repairtime++;
        AllSubstations++;
    }

    double averageRepairTime2 = RepairTime / AllSubstations;

    AllOtherSubstationsRepairTime.push_back(averageRepairTime2);
}



void CombinedRepairTime(int AverageTime , int averageRepairTime, int averageRepairTime2)
{
    AverageTime = averageRepairTime + averageRepairTime2 / 2;
}


void TotalCustomerHourInterruptions(int EBtickets, int OFtickets, int RLtickets, int TMtickets, int HDtickets, double averageRepairTime2)
{

    //Total Number of Customers Services per substation
   int EBtickets = { 5769 };
   int OFtickets = { 4413 };
   int RLtickets = { 3529 };
   int TMtickets = { 3436 };
   int HDtickets = { 5990 };

   double CustomerHourInterruptions = 0;
   double EBHourInterruptions = 0;
   double OFHourInterruptions = 0;
   double RLHourInterruptions = 0;
   double HDHourInterruptions = 0;
   double TMHourInterruptions = 0;


   //Displays the Total Customer Hour Interruptions. To Display separately , simply separate them & not add them together. 
   CustomerHourInterruptions = (EBtickets * averageRepairTime2) + (OFtickets * averageRepairTime2) + (RLtickets * averageRepairTime2) + (TMtickets * averageRepairTime2) + (HDtickets * averageRepairTime2);

   EBHourInterruptions = EBtickets * averageRepairTime2;
   OFHourInterruptions = OFtickets * averageRepairTime2;
   RLHourInterruptions = RLtickets * averageRepairTime2;
   HDHourInterruptions = HDtickets * averageRepairTime2;
   TMHourInterruptions = TMtickets * averageRepairTime2;
}


void dispatchingScheme()
{
    int RepairStatus = 1;

    while (RepairStatus == 1)
    {
        int TOT = 0; 
        int HospitalPower = 0, LocalPower = 0; 
        bool AssignedTeam = false;

        
        vector<Ticket> substationS;
        
        for (int i = 0; i < substationS.size() && HospitalPower < LocalPower; i++)
        {
            int N = 0;
            int crew = 0;

            if (substationS[i].cause == "Tree")
            {
                vector<Ticket> TreeCause;
                for (int j = 0; j < TreeCause.size(); j++)
                {
                    HospitalPower += ticket.CustomerHours - ticket.CAP;
                }
                if (!TreeCause.empty()) 
                {
                    N = crew / TreeCause.size();
                }

            }
            else if (substationS[i].cause == "Insulator")
            {
                vector<Ticket> InsulatorCause;
                for (int j = 0; j < InsulatorCause.size(); j++)
                {
                    HospitalPower += ticket.CustomerHours - ticket.CAP;
                }
                if (!InsulatorCause.empty()) 
                {
                    N = crew / InsulatorCause.size();
                }
            }

            else if (substationS[i].cause == "MVA")
            {
                vector <Ticket> MVAcause;
                for (int j = 0; j < MVAcause.size(); j++)
                {
                    HospitalPower += ticket.CustomerHours - ticket.CAP;
                }
                if (!MVAcause.empty()) 
                {
                    N = crew / MVAcause.size();
                }
            }

            TOT = TOT - N;

        }

        if (!AssignedTeam && TOT <= 0)
        {
            RepairStatus = 0;
            break;
        }
    }
}


