//ESE 224 Final Project Part 2 main
//Adam Arlotta and Victor Morales

#include <iostream>
#include <string>
#include <list>
#include <vector>
#include <fstream>
#include <sstream>
#include <numeric>
#include <filesystem>
#include "TicketsTask1.h"
#include "SourceFileTask2.cpp"

using namespace std;

int main()
{
	list<Team>::iterator it_team;
	list<Surgery>::iterator it_surgery;
	vector<Surgery> MVAcauses;
	vector<Surgery> InsulatorCauses;
	vector<Surgery> expectedPerformanceVector;

	vector<int> expectedPerformance;
	vector<int> timeWithoutPowerVector;
	TeamList tl;
	SurgeonList sl;
	SurgeryList sgyl;


	//declare hospitals 1 to 5 as objects
	Hospital H1;
	Hospital H2;
	Hospital H3;
	Hospital H4;
	Hospital H5;

	Team t;
	Surgeon sgeon;
	Surgery s;

	Position pos;

	string team;
	string surgeon;
	string surgery;
	int points;
	int time;
	string operation;
	string hospital;
	string actions;
	float average;
	string date1;
	string date2;
	float CAP;
	int outage;
	double avg_time;
	double N1, N2, N;
	double expected_surgeries;
	double expected_surgeries_of_difficulty;
	double energy_required;
	string cause;
	int PerformanceExpected;
	int timeWithoutPower;
	int expectedPerformanceData;
	int timeWithoutPowerData;
	double MVA_average;
	double insulator_average;

	H1.addRoot();
	H2.addRoot();
	H3.addRoot();
	H4.addRoot();
	H5.addRoot();

	int accessDataBase = 1;
	while (accessDataBase == 1)
	{
		cout << "Enter 1 to access Ticket DataBase(Task1)\n Enter 2 to access Surgeon DataBase(Task2)\n, Enter 3 for Power Minimization(Task3)\n ";
		int operation;
		cin >> operation;
		cin.ignore();

		cout << "\n";

		if (operation == 1)
		{
			int DataEntry = 1;
			while (DataEntry == 1)
			{
				// Prompt user to add a new ticket or update an existing one
				cout << "Enter 1(Add New ticket), 2(Update Ticket), 3(Display Specific Outage), 4(Enter Start/End date), or 0(Exit): ";
				int choice;
				cin >> choice;
				cin.ignore();

				cout << "\n";

				if (choice == 1)
				{
					// Prompt user for ticket information
					string line, substation, date, time, comment, cause;
					cout << "Enter the line: ";
					getline(cin, line);

					cout << "Enter the substation (EB, OF, RL, TM, or HD): ";
					getline(cin, substation);

					cout << "Enter the date (YYYY_MM_DD): ";
					getline(cin, date);

					cout << "Enter the time (HH:MM:SS): ";
					getline(cin, time);

					cout << "Enter the cause (Tree, Insulator, or MVA): ";
					getline(cin, cause);

					cout << "Enter the comment: ";
					getline(cin, comment);

					addTicket(line, substation, date, time, comment, cause);
				}
				else if (choice == 2)
				{
					// Prompt user for ticket index and updated information
					int index;
					string newComment, newTime, newDate;
					cout << "ALERT: Tickets Are Stored In The Order They Were Entered. First Ticket Is Index 0 & So On" << "\n";
					cout << "Enter the ticket index: ";
					cin >> index;
					cin.ignore();

					cout << "Enter the new time (HH:MM:SS): ";
					getline(cin, newTime);

					cout << "Enter the new date (YYYY_MM_DD): ";
					getline(cin, newDate);

					cout << "Enter the new comment: ";
					getline(cin, newComment);

					updateTicket(index, newComment, newTime, newDate);
				}

				else if (choice == 3)
				{
					// Prompt user for substation and cause information
					string cause;
					cout << "Enter the cause (Tree, Insulator, or MVA): ";
					getline(cin, cause);

					// Display the specific outage information

					displayOutage(cause);

				}

				else if (choice == 4)
				{
					string startDate, endDate;

					cout << "Enter The Start Date: ";
					getline(cin, startDate);

					cout << "Enter The End Date: ";
					getline(cin, endDate);

					displayBasedOnTime(tickets, startDate, endDate);
				}

				else if (choice == 0)
				{
					cout << "Quit" << endl;
					DataEntry = 0;
				}

				else
				{
					cout << "Invalid input. Enter Correct Information: " << endl;
				}

				cout << "\n";
			}

			cout << "\n";

			cout << "Please Enter a Substation: ";
			string substation;
			cin >> substation;

			cout << "Please Enter a cause: ";
			string cause;
			cin >> cause;

			cout << "Please Enter an Integer Value: ";
			int Y;
			cin >> Y;

			FindYParameters(substation, cause, Y);

			cout << "\n";

			cout << "Please Enter a cause: ";
			string cause1;
			cin >> cause1;

			cout << "Please Enter an Integer Value: ";
			int Y1;
			cin >> Y1;

			FindZParameter(substation, cause, tickets);
		}

		else if (operation == 2)
		{
			int accessHospitals = 1;
			while (accessHospitals == 1)
			{
				cout << "Enter Hospital To Access: H1, H2, H3, H4, or H5 or H6(EXIT): ";
				string hospital;
				cin >> hospital;
				cin.ignore();

				cout << "\n";

				if (hospital == "H1")
				{
					cout << "HOSPITAL 1" << endl;
					cout << "You are now in the performance data base for surgeons. Here are a list of actions you may perform: " << endl;
					cout << "If you would like to add a team of surgeons to the hospital data base, enter AT. " << endl;
					cout << "If you would like to remove a team of surgeons to the hospital data base, enter RT. " << endl;
					cout << "If you would like to add a surgeon to a team, enter AST. " << endl;
					cout << "If you would like to remove a surgeon from a team, enter RST. " << endl;
					cout << "If you would like to add a surgery to a specific team, enter ASTT. " << endl;
					cout << "If you would like to display all surgeries from a team, enter DST. " << endl;
					cout << "If you would like to display surgeries performed at a hospital, enter DSH. " << endl;
					cout << "If you would like to display all teams, enter DAT. " << endl;
					string actions;
					cin >> actions;

					if (actions == "AT")
					{
						cout << "Please enter a team you would like to add. " << endl;
						cin >> team;
						tl.push_back(t);
						H1.add_team(t);
					}

					else if (actions == "RT")
					{
						cout << "Please enter a team you would like to remove. " << endl;
						cin >> team;
						tl.push_back(t);
						H1.remove_team(H1, t);
					}

					else if (actions == "AST")
					{
						cout << "Please enter a surgeon to add. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to add the surgeon to. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H1.add_surgeon(sgeon);
					}

					else if (actions == "RST")
					{
						cout << "Please enter a surgeon to remove. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to remove the surgeon from. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H1.remove_surgeon(H1, sgeon);
					}

					else if (actions == "ASTT")
					{
						cout << "Please enter a surgery to add to a team. " << endl;
						cin >> surgery;
						cout << "Please enter a team you would like to add the surgery to. " << endl;
						cin >> team;
						cout << "How long was the surgery? (Please enter in minutes) " << endl;
						cin >> time;
						cout << "On a scale of 1 to 10, how difficult was the surgery? 1 being the easiest, and 10 being the hardest. " << endl;
						cin >> points;

						tl.push_back(t);
						sgyl.push_back(s);

						H1.add_surgery(s);
					}

					else if (actions == "DST")
					{
						H1.display_surgeries(s, average, sgyl);
					}

					else if (actions == "DSH")
					{
						cout << "Please enter a start date in format month date year" << endl;
						cin >> date1;
						cout << "Please enter an end date in format month date year" << endl;
						cin >> date2;

						H1.display_surgeries(s, date1, date2, sgyl);
					}

					else if (actions == "DAT")
					{
						H1.display_teams(t, average, tl);
					}
				}

				else if (hospital == "H2")
				{
					cout << "HOSPITAL 2" << endl;
					cout << "You are now in the performance data base for surgeons. Here are a list of actions you may perform: " << endl;
					cout << "If you would like to add a team of surgeons to the hospital data base, enter AT. " << endl;
					cout << "If you would like to remove a team of surgeons to the hospital data base, enter RT. " << endl;
					cout << "If you would like to add a surgeon to a team, enter AST. " << endl;
					cout << "If you would like to remove a surgeon from a team, enter RST. " << endl;
					cout << "If you would like to add a surgery to a specific team, enter ASTT. " << endl;
					cout << "If you would like to display all surgeries from a team, enter DST. " << endl;
					cout << "If you would like to display surgeries performed at a hospital, enter DSH. " << endl;
					cout << "If you would like to display all teams, enter DAT. " << endl;
					cin >> actions;

					if (actions == "AT")
					{
						cout << "Please enter a team you would like to add. " << endl;
						cin >> team;
						tl.push_back(t);
						H2.add_team(t);
					}

					else if (actions == "RT")
					{
						cout << "Please enter a team you would like to remove. " << endl;
						cin >> team;
						tl.push_back(t);
						H2.remove_team(H2, t);
					}

					else if (actions == "AST")
					{
						cout << "Please enter a surgeon to add. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to add the surgeon to. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H2.add_surgeon(sgeon);
					}

					else if (actions == "RST")
					{
						cout << "Please enter a surgeon to remove. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to remove the surgeon from. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H2.remove_surgeon(H2, sgeon);
					}

					else if (actions == "ASTT")
					{
						cout << "Please enter a surgery to add to a team. " << endl;
						cin >> surgery;
						cout << "Please enter a team you would like to add the surgery to. " << endl;
						cin >> team;
						cout << "How long was the surgery? (Please enter in minutes) " << endl;
						cin >> time;
						cout << "On a scale of 1 to 10, how difficult was the surgery? 1 being the easiest, and 10 being the hardest. " << endl;
						cin >> points;

						tl.push_back(t);
						sgyl.push_back(s);

						H2.add_surgery(s);
					}

					else if (actions == "DST")
					{
						H2.display_surgeries(s, average, sgyl);
					}

					else if (actions == "DSH")
					{
						cout << "Please enter a start date in format month date year" << endl;
						cin >> date1;
						cout << "Please enter an end date in format month date year" << endl;
						cin >> date2;

						H2.display_surgeries(s, date1, date2, sgyl);
					}

					else if (actions == "DAT")
					{
						H2.display_teams(t, average, tl);
					}
				}


				else if (hospital == "H3")
				{
					cout << "HOSPITAL 3" << endl;
					cout << "You are now in the performance data base for surgeons. Here are a list of actions you may perform: " << endl;
					cout << "If you would like to add a team of surgeons to the hospital data base, enter AT. " << endl;
					cout << "If you would like to remove a team of surgeons to the hospital data base, enter RT. " << endl;
					cout << "If you would like to add a surgeon to a team, enter AST. " << endl;
					cout << "If you would like to remove a surgeon from a team, enter RST. " << endl;
					cout << "If you would like to add a surgery to a specific team, enter ASTT. " << endl;
					cout << "If you would like to display all surgeries from a team, enter DST. " << endl;
					cout << "If you would like to display surgeries performed at a hospital, enter DSH. " << endl;
					cout << "If you would like to display all teams, enter DAT. " << endl;
					cin >> actions;
					cin.ignore();

					if (actions == "AT")
					{
						cout << "Please enter a team you would like to add. " << endl;
						cin >> team;
						tl.push_back(t);
						H3.add_team(t);
					}

					else if (actions == "RT")
					{
						cout << "Please enter a team you would like to remove. " << endl;
						cin >> team;
						tl.push_back(t);
						H3.remove_team(H3, t);
					}

					else if (actions == "AST")
					{
						cout << "Please enter a surgeon to add. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to add the surgeon to. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H1.add_surgeon(sgeon);
					}

					else if (actions == "RST")
					{
						cout << "Please enter a surgeon to remove. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to remove the surgeon from. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H3.remove_surgeon(H3, sgeon);
					}

					else if (actions == "ASTT")
					{
						cout << "Please enter a surgery to add to a team. " << endl;
						cin >> surgery;
						cout << "Please enter a team you would like to add the surgery to. " << endl;
						cin >> team;
						cout << "How long was the surgery? (Please enter in minutes) " << endl;
						cin >> time;
						cout << "On a scale of 1 to 10, how difficult was the surgery? 1 being the easiest, and 10 being the hardest. " << endl;
						cin >> points;

						tl.push_back(t);
						sgyl.push_back(s);

						H3.add_surgery(s);
					}

					else if (actions == "DST")
					{
						H3.display_surgeries(s, average, sgyl);
					}

					else if (actions == "DSH")
					{
						cout << "Please enter a start date in format month date year" << endl;
						cin >> date1;
						cout << "Please enter an end date in format month date year" << endl;
						cin >> date2;

						H3.display_surgeries(s, date1, date2, sgyl);
					}

					else if (actions == "DAT")
					{
						H3.display_teams(t, average, tl);
					}
				}

				else if (hospital == "H4")
				{
					cout << "HOSPITAL 4" << endl;
					cout << "You are now in the performance data base for surgeons. Here are a list of actions you may perform: " << endl;
					cout << "If you would like to add a team of surgeons to the hospital data base, enter AT. " << endl;
					cout << "If you would like to remove a team of surgeons to the hospital data base, enter RT. " << endl;
					cout << "If you would like to add a surgeon to a team, enter AST. " << endl;
					cout << "If you would like to remove a surgeon from a team, enter RST. " << endl;
					cout << "If you would like to add a surgery to a specific team, enter ASTT. " << endl;
					cout << "If you would like to display all surgeries from a team, enter DST. " << endl;
					cout << "If you would like to display surgeries performed at a hospital, enter DSH. " << endl;
					cout << "If you would like to display all teams, enter DAT. " << endl;
					cin >> actions;

					if (actions == "AT")
					{
						cout << "Please enter a team you would like to add. " << endl;
						cin >> team;
						tl.push_back(t);
						H4.add_team(t);
					}

					else if (actions == "RT")
					{
						cout << "Please enter a team you would like to remove. " << endl;
						cin >> team;
						tl.push_back(t);
						H4.remove_team(H4, t);
					}

					else if (actions == "AST")
					{
						cout << "Please enter a surgeon to add. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to add the surgeon to. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H4.add_surgeon(sgeon);
					}

					else if (actions == "RST")
					{
						cout << "Please enter a surgeon to remove. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to remove the surgeon from. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H4.remove_surgeon(H4, sgeon);
					}

					else if (actions == "ASTT")
					{
						cout << "Please enter a surgery to add to a team. " << endl;
						cin >> surgery;
						cout << "Please enter a team you would like to add the surgery to. " << endl;
						cin >> team;
						cout << "How long was the surgery? (Please enter in minutes) " << endl;
						cin >> time;
						cout << "On a scale of 1 to 10, how difficult was the surgery? 1 being the easiest, and 10 being the hardest. " << endl;
						cin >> points;

						tl.push_back(t);
						sgyl.push_back(s);

						H4.add_surgery(s);
					}

					else if (actions == "DST")
					{
						H4.display_surgeries(s, average, sgyl);
					}

					else if (actions == "DSH")
					{
						cout << "Please enter a start date in format month date year" << endl;
						cin >> date1;
						cout << "Please enter an end date in format month date year" << endl;
						cin >> date2;

						H4.display_surgeries(s, date1, date2, sgyl);
					}

					else if (actions == "DAT")
					{
						H4.display_teams(t, average, tl);
					}
				}

				else if (hospital == "H5")
				{
					cout << "HOSPITAL 5" << endl;
					cout << "You are now in the performance data base for surgeons. Here are a list of actions you may perform: " << endl;
					cout << "If you would like to add a team of surgeons to the hospital data base, enter AT. " << endl;
					cout << "If you would like to remove a team of surgeons to the hospital data base, enter RT. " << endl;
					cout << "If you would like to add a surgeon to a team, enter AST. " << endl;
					cout << "If you would like to remove a surgeon from a team, enter RST. " << endl;
					cout << "If you would like to add a surgery to a specific team, enter ASTT. " << endl;
					cout << "If you would like to display all surgeries from a team, enter DST. " << endl;
					cout << "If you would like to display surgeries performed at a hospital, enter DSH. " << endl;
					cout << "If you would like to display all teams, enter DAT. " << endl;
					cin >> actions;

					if (actions == "AT")
					{
						cout << "Please enter a team you would like to add. " << endl;
						cin >> team;
						tl.push_back(t);
						H5.add_team(t);
					}

					else if (actions == "RT")
					{
						cout << "Please enter a team you would like to remove. " << endl;
						cin >> team;
						tl.push_back(t);
						H5.remove_team(H1, t);
					}

					else if (actions == "AST")
					{
						cout << "Please enter a surgeon to add. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to add the surgeon to. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H5.add_surgeon(sgeon);
					}

					else if (actions == "RST")
					{
						cout << "Please enter a surgeon to remove. " << endl;
						cin >> surgeon;
						cout << "Please enter a team to remove the surgeon from. " << endl;
						cin >> team;
						tl.push_back(t);
						sl.push_back(sgeon);

						H5.remove_surgeon(H5, sgeon);
					}

					else if (actions == "ASTT")
					{
						cout << "Please enter a surgery to add to a team. " << endl;
						cin >> surgery;
						cout << "Please enter a team you would like to add the surgery to. " << endl;
						cin >> team;
						cout << "How long was the surgery? (Please enter in minutes) " << endl;
						cin >> time;
						cout << "On a scale of 1 to 10, how difficult was the surgery? 1 being the easiest, and 10 being the hardest. " << endl;
						cin >> points;

						tl.push_back(t);
						sgyl.push_back(s);

						H5.add_surgery(s);
					}

					else if (actions == "DST")
					{
						H5.display_surgeries(s, average, sgyl);
					}

					else if (actions == "DSH")
					{
						cout << "Please enter a start date in format month date year" << endl;
						cin >> date1;
						cout << "Please enter an end date in format month date year" << endl;
						cin >> date2;

						H5.display_surgeries(s, date1, date2, sgyl);
					}

					else if (actions == "DAT")
					{
						H5.display_teams(t, average, tl);
					}
				}

				else if (hospital == "H6")
				{
					cout << "Quit" << endl;
					accessHospitals = 0;
				}
			}

		}
	
		else if (operation == 3)
		{
			int minimizationData = 1;
			while (minimizationData == 1)
			{
				cout << "Please enter an option(1, 2, 3, 4, or 5(EXIT)): " << endl;
				int choice2;
				cin >> choice2;
				cin.ignore();

				cout << "\n";
				//3.1:
				if (choice2 == 1)
				{

					cout << "Please select a hospital. " << endl;
					cin >> hospital;

					if (hospital == "H1") {
						for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
						{
							for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
							{
								avg_time = std::accumulate(tl.begin(), tl.end(), 0.0) / tl.size();
							}
						}
					}

					else if (hospital == "H2")
					{
						for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
						{
							for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
							{
								avg_time = std::accumulate(tl.begin(), tl.end(), 0.0) / tl.size();
							}
						}
					}

					else if (hospital == "H3")
					{
						for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
						{
							for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
							{
								avg_time = std::accumulate(tl.begin(), tl.end(), 0.0) / tl.size();
							}
						}
					}

					else if (hospital == "H4")
					{
						for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
						{
							for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
							{
								avg_time = std::accumulate(tl.begin(), tl.end(), 0.0) / tl.size();
							}
						}
					}

					else if (hospital == "H5")
					{
						for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
						{
							for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
							{
								avg_time = std::accumulate(tl.begin(), tl.end(), 0.0) / tl.size();
							}
						}
					}

				}

				//3.2
				else if (choice2 == 2)
				{
					cout << "Please select a hospital. " << endl;
					cin >> hospital;

					if (hospital == "H1")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							double N1 = s.points;
							double N2 = std::accumulate(sgyl.begin(), sgyl.end(), 0.0) / avg_time;
						}
						double N = std::accumulate(sgyl.begin(), sgyl.end(), 0.0);

						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries = N1 / N * N2;
						}
					}

					else if (hospital == "H2")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							double N1 = s.points;
							double N2 = std::accumulate(sgyl.begin(), sgyl.end(), 0.0) / avg_time;
						}
						double N = std::accumulate(sgyl.begin(), sgyl.end(), 0.0);

						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries = N1 / N * N2;
						}
					}

					else if (hospital == "H3")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							double N1 = s.points;
							double N2 = std::accumulate(sgyl.begin(), sgyl.end(), 0.0) / avg_time;
						}
						double N = std::accumulate(sgyl.begin(), sgyl.end(), 0.0);

						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries = N1 / N * N2;
						}
					}

					else if (hospital == "H4")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							double N1 = s.points;
							double N2 = std::accumulate(sgyl.begin(), sgyl.end(), 0.0) / avg_time;
						}
						double N = std::accumulate(sgyl.begin(), sgyl.end(), 0.0);

						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries = N1 / N * N2;
						}
					}

					else if (hospital == "H5")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							double N1 = s.points;
							double N2 = std::accumulate(sgyl.begin(), sgyl.end(), 0.0) / avg_time;
						}
						double N = std::accumulate(sgyl.begin(), sgyl.end(), 0.0);

						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries = N1 / N * N2;
						}
					}
				}

				//3.3
				else if (choice2 == 3)
				{
					if (hospital == "H1")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries_of_difficulty = expected_surgeries / points;
						}
						for (tl.begin(); it_team != tl.end(); ++it_team) {
							avg_time = expected_surgeries_of_difficulty / avg_time;
						}
						energy_required = expected_surgeries_of_difficulty / avg_time;
					}

					if (hospital == "H2")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries_of_difficulty = expected_surgeries / points;
						}
						for (tl.begin(); it_team != tl.end(); ++it_team)
						{
							avg_time = expected_surgeries_of_difficulty / avg_time;
						}
						energy_required = expected_surgeries_of_difficulty / avg_time;
					}

					if (hospital == "H3")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries_of_difficulty = expected_surgeries / points;
						}
						for (tl.begin(); it_team != tl.end(); ++it_team)
						{
							avg_time = expected_surgeries_of_difficulty / avg_time;
						}
						energy_required = expected_surgeries_of_difficulty / avg_time;
					}

					if (hospital == "H4")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries_of_difficulty = expected_surgeries / points;
						}
						for (tl.begin(); it_team != tl.end(); ++it_team)
						{
							avg_time = expected_surgeries_of_difficulty / avg_time;
						}
						energy_required = expected_surgeries_of_difficulty / avg_time;
					}

					if (hospital == "H5")
					{
						for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
						{
							points = it_surgery->points;
							expected_surgeries_of_difficulty = expected_surgeries / points;
						}
						for (tl.begin(); it_team != tl.end(); ++it_team)
						{
							avg_time = expected_surgeries_of_difficulty / avg_time;
						}
						energy_required = expected_surgeries_of_difficulty / avg_time;
					}

				}

				//3.4
				else if (choice2 == 4)
				{
					cout << "Enter A Hospital(H1, H2, H3, H4, H5); ";
					string hospital;
					cin >> hospital;
					cin.ignore();

					cout << "\n";

					if (hospital == "H1")
					{
						cout << "What is the expected length of the power outage? (in hours)" << endl;
						cin >> outage;
						string yes_or_no;
						while (yes_or_no != "no")
						{
							cout << "Would you like to enter a surgery?" << endl;
							cin >> yes_or_no;
							cout << "Please enter name of surgery, and complexity of surgery on a scale of 1 to 10 from largest to smallest " << endl;
							cin >> surgery;
							cin >> points;
							sgyl.push_back(s);
						}

						cout << "Please enter the capacity of power for the hospital. " << endl;
						cin >> CAP;
						while (CAP > 0)
						{
							for (int i = 0; i < outage; i++)
							{
								for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
								{
									for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
									{
										if (it_team->points = points) {
											it_team->surgery = s.surgery;

											CAP = CAP - energy_required;
											double time_expected = avg_time;
										}
									}
								}
							}
						}
					}

					else if (hospital == "H2")
					{
						cout << "What is the expected length of the power outage? (in hours)" << endl;
						cin >> outage;
						string yes_or_no;
						while (yes_or_no != "no")
						{
							cout << "Would you like to enter a surgery?" << endl;
							cin >> yes_or_no;
							cout << "Please enter name of surgery, and complexity of surgery on a scale of 1 to 10 from largest to smallest " << endl;
							cin >> surgery;
							cin >> points;
							sgyl.push_back(s);
						}

						cout << "Please enter the capacity of power for the hospital. " << endl;
						cin >> CAP;
						while (CAP > 0) {
							for (int i = 0; i < outage; i++)
							{
								for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
								{
									for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
									{
										if (it_team->points = points) {
											it_team->surgery = s.surgery;

											CAP = CAP - energy_required;
											double time_expected = avg_time;
										}
									}
								}
							}
						}
					}

					else if (hospital == "H3")
					{
						cout << "What is the expected length of the power outage? (in hours)" << endl;
						cin >> outage;
						string yes_or_no;
						while (yes_or_no != "no")
						{
							cout << "Would you like to enter a surgery?" << endl;
							cin >> yes_or_no;
							cout << "Please enter name of surgery, and complexity of surgery on a scale of 1 to 10 from largest to smallest " << endl;
							cin >> surgery;
							cin >> points;
							sgyl.push_back(s);
						}

						cout << "Please enter the capacity of power for the hospital. " << endl;
						cin >> CAP;
						while (CAP > 0)
						{
							for (int i = 0; i < outage; i++)
							{
								for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
								{
									for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
									{
										if (it_team->points = points) {
											it_team->surgery = s.surgery;

											CAP = CAP - energy_required;
											double time_expected = avg_time;
										}
									}
								}
							}
						}
					}

					else if (hospital == "H4")
					{
						cout << "What is the expected length of the power outage? (in hours)" << endl;
						cin >> outage;
						string yes_or_no;
						while (yes_or_no != "no")
						{
							cout << "Would you like to enter a surgery?" << endl;
							cin >> yes_or_no;
							cout << "Please enter name of surgery, and complexity of surgery on a scale of 1 to 10 from largest to smallest " << endl;
							cin >> surgery;
							cin >> points;
							sgyl.push_back(s);
						}

						cout << "Please enter the capacity of power for the hospital. " << endl;
						cin >> CAP;
						while (CAP > 0)
						{
							for (int i = 0; i < outage; i++)
							{
								for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
								{
									for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
									{
										if (it_team->points = points)
										{
											it_team->surgery = s.surgery;

											CAP = CAP - energy_required;
											double time_expected = avg_time;
										}
									}
								}
							}
						}
					}

					else if (hospital == "H5")
					{
						cout << "What is the expected length of the power outage? (in hours)" << endl;
						cin >> outage;
						string yes_or_no;
						while (yes_or_no != "no")
						{
							cout << "Would you like to enter a surgery?" << endl;
							cin >> yes_or_no;
							cout << "Please enter name of surgery, and complexity of surgery on a scale of 1 to 10 from largest to smallest " << endl;
							cin >> surgery;
							cin >> points;
							sgyl.push_back(s);
						}

						cout << "Please enter the capacity of power for the hospital. " << endl;
						cin >> CAP;
						while (CAP > 0)
						{
							for (int i = 0; i < outage; i++)
							{
								for (it_surgery = sgyl.begin(); it_surgery != sgyl.end(); ++it_surgery)
								{
									for (it_team = tl.begin(); it_team != tl.end(); ++it_team)
									{
										if (it_team->points = points)
										{
											it_team->surgery = s.surgery;

											CAP = CAP - energy_required;
											double time_expected = avg_time;
										}
									}
								}
							}
						}
					}
				}

				else if (choice2 == 5)
				{
					cout << "Quit." << endl;
					minimizationData = 0;
				}
			}
		}

		else if (operation == 5)
		{
			cout << "Exiting DataBase";
			accessDataBase = 0;
		}

		return 0;
	}
}

