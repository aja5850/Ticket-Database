#include <iostream>
#include <string>
#include <list>

using namespace std;

struct Node {//dummy node for the root of a hospital
    Node* par;
    Node* child;
    Node() : par(NULL), child(NULL) {	}
};

struct Team {//team name to be added to the hospital
    string team;
    Node* node;
    Node* par;
    //Team *par;
    Team* child;
    Team* t;
    float average;
    int points;
    string surgery;
    Team() : average(0.0), team(""), node(NULL), par(NULL), child(NULL) { }
};

typedef std::list<Team> TeamList;

struct Surgeon {//surgeon name to be added to team
    string surgeon;
    Team* par;
    Team* t;
    //Surgeon *par;
    Surgeon* child;
    Surgeon* sgn;
    Surgeon() : surgeon(""), par(NULL), child(NULL) { }
};

typedef std::list<Surgeon> SurgeonList;

struct Surgery {//surgery to be added to team
    Team* par;
    Team* t;
    //Surgery *par;
    Surgery* sgy;
    Surgery* child;
    int time;
    string date1, date2;
    int points;
    float average;
    double avg_time;
    string surgery;
    Surgery() : time(0), date1(""), date2(""), points(0), average(0.0), par(NULL), child(NULL), surgery("") { }
};

typedef std::list<Surgery> SurgeryList;

class Hospital;//Hospital class will be an object for each hospital

class Position {//position class will store the teams, surgeons, and surgeries. Also declares start and end dates, time needed to complete a surgery, points for difficulty scale, average points in a given amount of time.
private:
    Node* v;
    Team* t;
    Surgeon* sgn;
    Surgery* sgy;

public:
    Position(Node* _v = NULL) : v(_v) { }
    Position child() const { return Position(v->child); }
    Position parent() const { return Position(v->par); }
    bool isRoot() const { return v->par == NULL; }
    friend class Hospital;
};

typedef std::list<Position> PositionList;//position list stores the contents of the class

class Hospital {
public:
    Hospital();
    int size() const;
    bool empty() const;
    Position root() const;
    void addRoot();
    void add_team(const Team& te);//adds team of surgeon to the data base
    void add_surgeon(const Surgeon& surn);//adds surgeon to team
    void add_surgery(const Surgery& srgry);//adds surgery to surgeon
    Position remove_team(const Hospital& H, Team& te);
    Position remove_surgeon(const Hospital& H, Surgeon& surn);
    void display_surgeries(const Surgery& sgy, float avg, SurgeryList& sl) const;//displays surgeries for each team
    void display_surgeries(const Surgery& sgy, const string& d1, const string& d2, SurgeryList& sl) const;//displays surgeries by time
    void display_teams(const Team& tm, float avg, TeamList& tl) const;//displays teams at all hospitals by average points

private:
    Node* _root;
    Team* _root1;
    Surgeon* _root2;
    Surgery* _root3;
    int n;
};

