#include <iostream>
#include <string>
#include <list>
#include "HeaderFileTask2.h"

using namespace std;

Hospital::Hospital() : _root(NULL), n(0) {//constructor
	//root starts as null
	//size starts as empty
}

int Hospital::size() const {
	return n;//return n
}

bool Hospital::empty() const {
	return size() == 0;//if empty, the size is just 0
}

Position Hospital::root() const {
	return Position(_root);//returns the root
}

void Hospital::addRoot() {
	_root = new Node;//root will be equal to the new node
	n = 1;//size is just one node
}

void Hospital::add_team(const Team& te) {
	Team* t = te.t;


	t->child = new Team;//child of team creates a new node named team
	t->par = t->node;//parent of team is node (root)

	n = n + 1;
}

void Hospital::add_surgeon(const Surgeon& sugn) {
	Surgeon* sgn = sugn.sgn;

	sgn->child = new Surgeon;
	sgn->par = sgn->t;//the parent of the surgeon node is the team

	n = n + 1;
}

void Hospital::add_surgery(const Surgery& srgry) {
	Surgery* sgy = srgry.sgy;

	sgy->child = new Surgery;
	sgy->par = sgy->t;

	n = n + 1;
}


Position Hospital::remove_surgeon(const Hospital& H, Surgeon& sugn) {
	Surgeon* sgn = sugn.sgn;
	delete sgn;
	n = n - 1;

	return 0;
}

Position Hospital::remove_team(const Hospital& H, Team& te) {
	Team* t = te.t;
	delete t;
	n = n - 1;

	return 0;
}

void Hospital::display_surgeries(const Surgery& sgy, const string& d1, const string& d2, SurgeryList& sl) const {
	Surgery* s = nullptr;
	s->date1 = d1;
	s->date2 = d2;
	sl.push_back(sgy);
	display_surgeries(sgy, d1, d2, sl);
}

void Hospital::display_surgeries(const Surgery& sgy, float avg, SurgeryList& sl) const {
	Surgery* s = nullptr;
	s->average = avg;
	sl.push_back(sgy);
	display_surgeries(sgy, avg, sl);
}

void Hospital::display_teams(const Team& tm, float avg, TeamList& tl) const {
	Team* t = nullptr;
	t->average = avg;
	tl.push_back(tm);
	display_teams(tm, avg, tl);
}

