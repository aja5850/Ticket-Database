#include <iostream>
#include <string>
#include <vector>

using namespace std;

// Contains Information for Ticket
struct Ticket
{
    string line;
    string substation;
    string date;
    string time;
    string remark;
    string comment;
    string cause;

    vector<string> repairSteps;
};

// Main Ticket Vector
vector<Ticket> tickets;

// Substation subvectors
vector<Ticket> EBtickets;
vector<Ticket> OFtickets;
vector<Ticket> RLtickets;
vector<Ticket> TMtickets;
vector<Ticket> HDtickets;

// Cause subvectors
vector<Ticket> TreeCause;
vector<Ticket> InsulatorCause;
vector<Ticket> MVACause;

vector<Ticket> newRepairStep;

// Add a new ticket for a new power outage
void addTicket(string line, string substation, string date, string time, string comment, string cause)
{
    Ticket newTicket;
    newTicket.line = line;
    newTicket.substation = substation;
    newTicket.date = date;
    newTicket.time = time;
    newTicket.comment = comment;
    newTicket.cause = cause;
    tickets.push_back(newTicket);

    // Push the ticket to the corresponding substation vector
    if (substation == "EB")
    {
        if (cause == "Tree")
        {
            TreeCause.push_back(newTicket);
            EBtickets.push_back(newTicket);
        }
        else if (cause == "Insulator")
        {
            InsulatorCause.push_back(newTicket);
            EBtickets.push_back(newTicket);
        }
        else if (cause == "MVA") {
            MVACause.push_back(newTicket);
            EBtickets.push_back(newTicket);
        }
    }
    else if (substation == "OF") {
        if (cause == "Tree") {
            TreeCause.push_back(newTicket);
            OFtickets.push_back(newTicket);
        }
        else if (cause == "Insulator") {
            InsulatorCause.push_back(newTicket);
            OFtickets.push_back(newTicket);
        }
        else if (cause == "MVA") {
            MVACause.push_back(newTicket);
            OFtickets.push_back(newTicket);
        }
    }
    else if (substation == "RL")
    {
        if (cause == "Tree")
        {
            TreeCause.push_back(newTicket);
            RLtickets.push_back(newTicket);
        }
        else if (cause == "Insulator")
        {
            InsulatorCause.push_back(newTicket);
            RLtickets.push_back(newTicket);
        }
        else if (cause == "MVA") {
            MVACause.push_back(newTicket);
            RLtickets.push_back(newTicket);
        }
    }

    else if (substation == "TM")
    {
        if (cause == "Tree")
        {
            TreeCause.push_back(newTicket);
            TMtickets.push_back(newTicket);
        }
        else if (cause == "Insulator")
        {
            InsulatorCause.push_back(newTicket);
            TMtickets.push_back(newTicket);
        }
        else if (cause == "MVA")
        {
            MVACause.push_back(newTicket);
            TMtickets.push_back(newTicket);
        }
    }
    else if (substation == "HD")
    {
        if (cause == "Tree")
        {
            TreeCause.push_back(newTicket);
            HDtickets.push_back(newTicket);
        }
        else if (cause == "Insulator")
        {
            InsulatorCause.push_back(newTicket);
            HDtickets.push_back(newTicket);
        }
        else if (cause == "MVA")
        {
            MVACause.push_back(newTicket);
            HDtickets.push_back(newTicket);
        }
    }
}

void updateTicket(int index, const string& newRemark, const string& newTime, const string& newDate)
{
    if (index >= 0 && index < tickets.size())
    {
        Ticket& ticket = tickets[index];
        ticket.time = newTime;
        ticket.remark = newRemark;
        ticket.date = newDate;
    }
    else
    {
        cout << "Invalid ticket index" << endl;
    }
}



void displayOutage(string cause)
{
    vector<Ticket>* causeTickets;

    if (cause == "Tree")
    {
        causeTickets = &TreeCause;
    }
    else if (cause == "Insulator")
    {
        causeTickets = &InsulatorCause;
    }
    else if (cause == "MVA")
    {
        causeTickets = &MVACause;
    }
    else
    {
        cout << "Invalid cause entered." << endl;
        return;
    }

    if (causeTickets->empty())
    {
        cout << "No outages found for the specified cause." << endl;
        return;
    }

    cout << "Outages for cause: " << cause << endl << endl;

    for (int i = 0; i < causeTickets->size(); i++)
    {
        Ticket& ticket = (*causeTickets)[i];

        
        cout << "Line: " << ticket.line << " | Substation: " << ticket.substation << " | Cause: " << ticket.cause << " | Date: " << ticket.date << " | Time: " << ticket.time << " | Comment: " << ticket.comment << endl;

    }
}

void displayBasedOnTime(const vector<Ticket>& tickets, const string& startDate, const string& endDate)
{
    bool TicketFound = false;
    for (int i = 0; i < tickets.size(); i++)
    {
        const Ticket& ticket = tickets[i];
        if (ticket.date >= startDate && ticket.date <= endDate)
        {
            TicketFound = true;
            cout << "Line: " << ticket.line << ", Substation: " << ticket.substation << ", Date: " << ticket.date << ", Time: " << ticket.time << "\n";
            cout << "Repair Steps: ";
            for (int j = 0; j < ticket.repairSteps.size(); j++)
            {
                cout << ticket.repairSteps[j] << ", ";
            }
            cout << "\n";
        }
    }

    if (!TicketFound)
    {
        cout << "No Tickeds Found" << endl;
    }
}

void FindYParameters(const string& substation, const string& cause, int Y)
{

    int MVAcause = 0;
    int TreeCause = 0;
    int InsulatorCause = 0;

    for (int i = 0; i < tickets.size(); i++) 
    {
        Ticket& ticket = tickets[i];
        if (ticket.substation == substation) 
        {
            if (ticket.cause == "MVA") 
            {
                MVAcause++;
            }
            else if (ticket.cause == "Tree") 
            {
                TreeCause++;
            }
            else if (ticket.cause == "Insulator") 
            {
                InsulatorCause++;
            }
        }
    }
   
}

void FindZParameter(string substation, string cause, vector<Ticket>& tickets)
{
    int count = 0;
    for (int i = 0; i < tickets.size(); i++)
    {
        if (tickets[i].substation == substation && tickets[i].cause == cause)
        {
            count++;

            cout << "Number Identified: " << count << endl;
        }
    }
}



